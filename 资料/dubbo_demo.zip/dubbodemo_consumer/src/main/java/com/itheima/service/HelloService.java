package com.itheima.service;

public interface HelloService {
    public String sayHello(String name);

    public String add(int addend1 ,int addend2);
}
